import pywt
import numpy as np 
coeffs2 = pywt.dwt2(original, 'bior1.3')

