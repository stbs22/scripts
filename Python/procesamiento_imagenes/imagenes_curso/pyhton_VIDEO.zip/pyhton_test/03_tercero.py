## Codigo basado en Kardi Teknomo Copyright © 2017 

import numpy as np
import cv2

scaling_factorx=0.9
scaling_factory=0.9

cap = cv2.VideoCapture(0)
while(True):
    # Capture frame-by-frame
    ret, frame = cap.read()  # ret = 1 if the video is captured; frame is the image
    frame=cv2.resize(frame,None,fx=scaling_factorx,fy=scaling_factory,interpolation=cv2.INTER_AREA)
    
    # Our operations on the frame come here    
    img = frame
    
    # Display the resulting image
    cv2.imshow('Smaller Window',img)
    if cv2.waitKey(1) & 0xFF == ord('q'):  # press q to quit
        break
        
# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()

