#include "pregunta2.h"

void divide_lista_genero(struct p **lista, struct p **lista_m, struct p **lista_h){
	
}