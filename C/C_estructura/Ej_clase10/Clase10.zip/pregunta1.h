#include "funciones.h"

void ordenar(struct p **lista);
