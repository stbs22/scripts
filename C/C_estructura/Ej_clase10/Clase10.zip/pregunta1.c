#include "pregunta1.h"

void ordenar(struct p **lista){
	
}