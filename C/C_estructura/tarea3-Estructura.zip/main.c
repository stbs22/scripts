#include "lib.h"

//ESTRUCTURA DE DATOS Y ALGORITMOS
//TICS311 Seccion_01 2021

// Andres Guevara
// Esteban Hernández
// Mátias Hermosilla



int main(int argc, char **argv) {

  //-------------------------------------------
  
  FILE *archivo2 = fopen(argv[1],"r");

  HashNodo* tabla[26];
  HashNodo* tabla_exclusiva_de_andres_NO_BORRAR[26];
  HashNodo* alumno;
  
  //-------------------------------------------
  
  argv_excepcion(argv);

  FILE *archivo = fopen(argv[1],"r");
  
  int nfilas = cont_filas(archivo);
  int ncolum = cont_col(archivo);
  

  char** nombre = crea_nombres(archivo,nfilas);
  
  float* listamean = crea_means(archivo,nfilas,ncolum);

  HashNodo** tabla_hash = crea_hash(nombre, listamean, nfilas);
  
  printf("Cantidad de Filas: %i, Columnas: %i\n",nfilas,ncolum);

  for(int i = 1; i < nfilas; i++){
    printf("chupapi munyayo: %s - P: %f",nombre[i],listamean[i]);
    printf("\n");
  }
  
  //display(tabla_hash);
  

  return 0;
}